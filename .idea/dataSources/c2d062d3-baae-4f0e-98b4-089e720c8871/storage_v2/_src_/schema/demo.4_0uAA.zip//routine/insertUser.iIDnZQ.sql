create
    definer = root@localhost procedure insertUser(IN _name varchar(120), IN _email varchar(120),
                                                  IN _country varchar(120))
BEGIN
    INSERT INTO users (name, email, country) VALUES (_name,_email,_country);
end;

